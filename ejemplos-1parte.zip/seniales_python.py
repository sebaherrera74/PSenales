import matplotlib.pyplot as plt
la 

t=[0,1,2]
s=[20,10,30]

plt.plot(t,s,'ro-')
plt.show()



