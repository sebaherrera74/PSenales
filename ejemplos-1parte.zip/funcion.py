def func(a,b):
    a=a+2.0
    b.append('1')
    print(a , b) 

#func(2,3)
#func(2,'3')
func(2,[2])
func(2,[])